package Main;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import treepye.ELKController;
import treepye.ELKInstance;
import treepye.Common;
import treepye.ElasticController;


public class GetELKMetrics {

	/**
	 * @param args
	 * @throws ParseException 
	 */
	public static void main(String[] args) throws ParseException {
		
		// TODO Auto-generated method stub
		//String metric = "";
				
		/*if(args.length <=0)
		{
			System.out.println("Please pass the metric name");
		    System.exit(0);
		}*/
		
		//metric = args[0];
		//metric = "cpu";
		Common.LoadConfigurations();
		if(Common.properies != null)
		{
			ElasticController elkc = new ElasticController();
			List<ELKInstance> instances = elkc.GetAllActiveELKInstances();
			
			//ELKController awsc = new ELKController();
			
			//List<ELKMetricUpdate> list = new ArrayList<ELKMetricUpdate>();
			
			
			if(instances != null)
			{
				for(ELKInstance i : instances)
				{
					if(i.status.toLowerCase().equals("active"))
					{
						//ELKMetricUpdate mt = new ELKMetricUpdate(i, i.ip_address, i.port);
						ELKController awsc = new ELKController();
					    
						String metricResponse = awsc.GetMetric(i.ip_address, i.port);
						@SuppressWarnings("unused")
						String elasticResponse = elkc.saveOSMetricDataToElastic(i, metricResponse);
						System.out.println("CPU% and MEM% is updated for the instance with id "+i._id+".");
						//System.out.println(elasticResponse);
					}
					
				}
				
				
			}
			
			
		}
		
	}
	
	