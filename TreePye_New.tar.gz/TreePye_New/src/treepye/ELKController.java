package treepye;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


public class ELKController {
	
	public String GetMetric(String ip_address, String port)
	{
		String jsonResponse = "";
		String filterQuery = "{ }";
		
		String ElasticHost = ip_address;
		String ElasticPort = port;
		String elasticPath = Common.getProperty("ELASTIC_METRIC"); 
		
		String command[]= {"curl","-XGET", "http://"+ElasticHost+":"+ElasticPort+"/"+elasticPath,"-H","Content-Type:application/json","-d", filterQuery};
		//System.out.println(command[0]+" "+command[1]+" "+command[2]+" "+command[3]+" "+command[4]+" "+command[5]+" "+command[6]);
		//System.exit(0);
		try {
			ProcessBuilder builder = new ProcessBuilder(command);
			Process process;
			
			process = builder.start();				 
		    
		    InputStream is = process.getInputStream();
		    InputStreamReader isr = new InputStreamReader(is);
		    BufferedReader br = new BufferedReader(isr);
		    String line;
		    StringBuffer response = new StringBuffer();
		    while ((line = br.readLine()) != null) {
		    	response.append(line);
		    
		    }
		    br.close();
		    jsonResponse = response.toString();	
		    //System.out.println("/" + jsonResponse + "/");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			jsonResponse = "";
			System.out.println("Error ELK Get Response : "+e.getMessage());
		}
		//System.out.println(jsonResponse);
		return jsonResponse;
	    
	}
	
	public List<ELKInstance> GetAllActiveELKInstances()
	{
		ElasticController elk = new ElasticController();
		List<ELKInstance> instances = elk.GetAllELKInstances();
		List<ELKInstance> activeinstances = null;
		
		if(instances.size() > 0 ) 
		{
			activeinstances = new ArrayList<ELKInstance>();
			for(ELKInstance ei : instances)
			{
				if(ei.status.equals("active")) 
				{
					activeinstances.add(ei);
				}
			}
		}
		
		
		return activeinstances;
		
	}
	

}
