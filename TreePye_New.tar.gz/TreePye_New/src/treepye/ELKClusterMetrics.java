package treepye;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;



import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.JsonNode;

public class ELKClusterMetrics {
	@JsonIgnore
	public String _id;
	public String user_id;
	public String ip;
	public String status;
	public int number_of_data_nodes;
	public int number_of_nodes;
	public int active_primary_shards;
	public int active_shards;
	public int relocating_shards;
	public int initializing_shards;
	public int unassigned_shards;
	public int delayed_unassigned_shards;
	public Date timestamp;
	public String instance_id;
	
	public ELKClusterMetrics()
	{
		this._id = "";
		this.user_id = "";
		this.ip = "";
		this.status = "";
		this.timestamp = null;
		this.number_of_data_nodes = 0;
		this.number_of_nodes = 0;
		this.active_primary_shards = 0;
		this.active_shards = 0;
		this.relocating_shards = 0;
		this.initializing_shards = 0;
		this.unassigned_shards = 0;
		this.delayed_unassigned_shards = 0;
		this.instance_id = "";
	}
	
	public ELKClusterMetrics(JsonNode node) throws ParseException
	{
		
		Date date = new Date();
		@SuppressWarnings("unused")
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		this.timestamp = date;
				
		this._id = "";
		this.user_id = "";
		this.ip = "";
		this.instance_id = "";
		this.status = node.path("status").asText();
		//System.out.println(node);
		
		//System.out.println(this.timestamp);
		this.number_of_data_nodes = node.path("number_of_data_nodes").asInt();
		this.number_of_nodes = node.path("number_of_nodes").asInt();
		this.active_primary_shards = node.path("active_primary_shards").asInt();
		this.active_shards = node.path("active_shards").asInt();
		this.relocating_shards = node.path("relocating_shards").asInt();
		this.initializing_shards = node.path("initializing_shards").asInt();
		this.unassigned_shards = node.path("unassigned_shards").asInt();
		this.delayed_unassigned_shards = node.path("delayed_unassigned_shards").asInt();
	}
	
}
