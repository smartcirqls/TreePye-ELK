package treepye;

import java.util.Date;

import treepye.Common;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.JsonNode;

public class ELKMetrics {
	@JsonIgnore
	public String _id;
	public String user_id;
	public String ip;
	public int cpu_percent;
	public int memory_used_percent;
	public int read_kilobytes;
	public int write_kilobytes;
	public Date timestamp;
	public String instance_id;
	public String node_name;
	public int query_total;
	public int query_time_in_millis;
	public int query_current;
	public int fetch_total;
	public int fetch_time_in_millis;
	public int fetch_current;
	public int index_time_in_millis; //indexing
	public int index_total; //indexing
	public int index_current; //indexing
	public int merges_current_docs; // merges
	public int merges_total_docs;  // merges
	public int refresh_total; // refresh
	public int flush_total; // flush
	public int flush_total_time_in_millis; //flush
	public int refresh_total_time_in_millis;
	public int jvm_heap_used_in_bytes;
	public int jvm_heap_committed_in_bytes;
	public int gc_young_collection_count;
	public int gc_young_collection_time_in_millis;
	public int gc_old_collection_count;
	public int gc_old_collection_time_in_millis;
	

	public ELKMetrics()
	{
		this._id = "";
		this.user_id = "";
		this.ip = "";
		this.cpu_percent = 0;
		this.timestamp = null;
		this.memory_used_percent = 0;
		this.read_kilobytes = 0;
		this.read_kilobytes = 0;
		this.instance_id = "";
		this.node_name = "";
		this.query_total = 0;
		this.query_time_in_millis = 0;
		this.query_current = 0;
		this.fetch_total = 0;
		this.fetch_time_in_millis = 0;
		this.fetch_current = 0;
		this.index_time_in_millis = 0;
		this.index_total = 0;
		this.index_current = 0;
		this.merges_current_docs = 0;
		this.merges_total_docs = 0;
		this.refresh_total = 0;
		this.flush_total = 0;
		this.flush_total_time_in_millis = 0;
		this.refresh_total_time_in_millis = 0;
		this.jvm_heap_used_in_bytes = 0;
		this.jvm_heap_committed_in_bytes = 0;
		this.gc_young_collection_count = 0;
		this.gc_young_collection_time_in_millis = 0;
		this.gc_old_collection_count = 0;
		this.gc_old_collection_time_in_millis = 0;
	}
	
	public ELKMetrics(JsonNode node)
	{
		/*String time = node.path("timestamp").asText();
		java.util.Date d = new java.util.Date(Long.parseLong(time));
		this.timestamp = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.SSS").format(d);*/
		//System.exit(0);
		//JsonNode datanode = node.path("nodes").path("UouaPEyIRh2Aj-9ywb_aog");
		
		
		this.timestamp = Common.GetConvertedTimeStamp(node.path("timestamp").asText());
		
		this._id = "";
		this.user_id = "";
		this.ip = "";
		this.instance_id = "";
	    //OS Metrics
		this.cpu_percent = node.path("os").path("cpu").path("percent").asInt();
		this.memory_used_percent = node.path("os").path("mem").path("used_percent").asInt();
		this.node_name = node.path("name").asText();
		this.read_kilobytes = node.path("fs").path("io_stats").path("total").path("read_kilobytes").asInt();
		this.write_kilobytes = node.path("fs").path("io_stats").path("total").path("write_kilobytes").asInt();
		//Search Metrics
		this.query_total = node.path("indices").path("search").path("query_total").asInt();
		this.query_time_in_millis = node.path("indices").path("search").path("query_time_in_millis").asInt();
		this.query_current = node.path("indices").path("search").path("query_current").asInt();
		this.fetch_total = node.path("indices").path("search").path("fetch_total").asInt();
		this.fetch_time_in_millis = node.path("indices").path("search").path("fetch_time_in_millis").asInt();
		this.fetch_current = node.path("indices").path("search").path("fetch_current").asInt();
		//Index Metrics
		this.index_time_in_millis = node.path("indices").path("indexing").path("index_time_in_millis").asInt();
		this.index_total = node.path("indices").path("indexing").path("index_total").asInt();
		this.index_current = node.path("indices").path("indexing").path("index_current").asInt();
		this.merges_current_docs = node.path("indices").path("merges").path("current_docs").asInt();
		this.merges_total_docs = node.path("indices").path("merges").path("total_docs").asInt();
		this.refresh_total = node.path("indices").path("refresh").path("total").asInt();
		this.refresh_total_time_in_millis = node.path("indices").path("refresh").path("total_time_in_millis").asInt();
		this.flush_total = node.path("indices").path("flush").path("total").asInt();
		this.flush_total_time_in_millis = node.path("indices").path("flush").path("total_time_in_millis").asInt();
		//JVM Metrics
		this.jvm_heap_used_in_bytes = node.path("jvm").path("mem").path("heap_used_in_bytes").asInt();
		this.jvm_heap_committed_in_bytes = node.path("jvm").path("mem").path("heap_committed_in_bytes").asInt();
		this.gc_young_collection_count = node.path("jvm").path("gc").path("collectors").path("young").path("collection_count").asInt();
		this.gc_young_collection_time_in_millis = node.path("jvm").path("gc").path("collectors").path("young").path("collection_time_in_millis").asInt();
		this.gc_old_collection_count = node.path("jvm").path("gc").path("collectors").path("old").path("collection_count").asInt();
		this.gc_old_collection_time_in_millis = node.path("jvm").path("gc").path("collectors").path("old").path("collection_time_in_millis").asInt();
		
	}
	
}