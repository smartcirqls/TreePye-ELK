package treepye;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.JsonNode;

public class ELKInstance {
	@JsonIgnore
	public String _id;
	public String user_id;
	public String instance_role;
	public String ip_address;
	public String port;
	public String created;
	public String created_by;
	public String modified;
	public String modified_by;
	public String status;
	

	
	public ELKInstance()
	{
		this._id = "";
		this.user_id = "";
		this.instance_role = "";
		this.ip_address = "";
		this.port = "";
		this.created = "";
		this.created_by = "";
		this.modified = "";
		this.modified_by = "";
		this.status = "";
	}
	
	/*public ELKInstance(Instance instance)
	{
		this._id = "";
		this.elk_account_id = "";
		this.instance_role = instance.getInstanceRole();
		this.ip_address = instance.getIpAddress();
		this.port = instance.getPort();
	}*/
	
	public ELKInstance(JsonNode node)
	{
		this._id = node.path("_id").asText();
		this.user_id = node.path("_source").path("user_id").asText();
		this.instance_role = node.path("_source").path("instance_role").asText();
		this.ip_address = node.path("_source").path("ip_address").asText();
		this.port = node.path("_source").path("port").asText();
		this.created = node.path("_source").path("created").asText();
		this.created_by = node.path("_source").path("created_by").asText();
		this.modified = node.path("_source").path("modified").asText();
		this.modified_by = node.path("_source").path("modified_by").asText();
		this.status = node.path("_source").path("status").asText();
	}
}